package net.o2oa.demos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;

import org.apache.commons.codec.binary.StringUtils;
import org.json.JSONObject;

import net.o2oa.util.Crypto;

/**
 * 此示例演示如何通过登录用户名，和SSO相关的配置，使用单点认证的方式进行O2Server的登录认证，获取xtoken信息
 * 涉及到加密解密，请使用非中文的唯一标识进行登录 ，中文登录 有可能会有找不到用户的问题。
 * @author O2OA
 */
public class Demo_LoginWithSSO {
	
	static final String  URL_SSOLOGIN="/x_organization_assemble_authentication/jaxrs/sso";
	
	public static void main( String[] args ) {
		String applicationServer = "127.0.0.1";
		Integer applicationPort = 20020;
		String userName = "13533441287";
		String ssoClient = "sso_demo";
		String key = "sso123456";
		
		try {
			LoginResult result = login(applicationServer, applicationPort, userName, ssoClient, key);
			if( StringUtils.equals( "success", result.getType() )) {
				System.out.println("xtoken=" + result.getToken() );
			}else {
				System.out.println("message:" + result.getMessage() );
			}			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//服务地址：http://127.0.0.1:20020/x_organization_assemble_authentication/jaxrs/sso
	//{"token":"xadmin","client":"sso_demo"}
	/**
	 * 使用登录认证的接口进行服务器登录，获取xtoken信息
	 * @param applicationServer  127.0.0.1
	 * @param applicationPort     20020
	 * @param userName             张三
	 * @param client                    sso_demo
	 * @param key                       sso123456
	 * @return
	 * @throws Exception
	 */
    public static LoginResult login( String applicationServer, Integer applicationPort, String userName, String client, String key ) throws Exception {
        //参数
    	String loginUrl = "http://" + applicationServer + ":" + applicationPort + URL_SSOLOGIN ;
    	String xtoken = Crypto.encrypt( userName + "#" + new Date().getTime(), key );
        String loginParams = String.format("{'token':'%s','client':'%s'}", xtoken, client );
        
        String responseData = sendPost( loginUrl, loginParams );

        /**
         * 成功响应结果
         * {
			  "type": "success",
			  "data": {
			    "token": "Xb9XTOjIQJa5AVRfHfIbNMFvhYdVfLgaipZBZBiUF7aNHeLrQ4vOu9YgprWeK2E1YsxApE_z4f1mvqvStFQI5CW7Pk31ulroUVAeR5jUybQ",
			    "roleList": [],
			    "id": "1cb47e12-18ad-4363-a55f-4514edb76215",
			    "genderType": "m",
			    "signature": "",
			    "pinyin": "lisi",
			    "pinyinInitial": "ls",
			    "description": "",
			    "name": "李四",
			    "employee": "",
			    "unique": "c93b7fb8-6820-466c-ab9c-f0637b8a3682",
			    "distinguishedName": "李四@c93b7fb8-6820-466c-ab9c-f0637b8a3682@P",
			    "orderNumber": 56649305,
			    "controllerList": [],
			    "superior": "",
			    "changePasswordTime": "2019-10-18",
			    "mail": "",
			    "weixin": "",
			    "qq": "",
			    "mobile": "13533441287",
			    "officePhone": "",
			    "createTime": "2019-10-18 15:55:05",
			    "updateTime": "2019-10-18 15:55:05"
			  },
			  "message": "",
			  "date": "2019-10-19 15:12:10",
			  "spent": 141,
			  "size": -1,
			  "count": 0,
			  "position": 0
			}**/
        
        /**
         * 失败响应结果 
         * {
			    "readyState": 4,
			    "responseText": "{\n  \"type\": \"error\",\n  \"message\": \"用户不存在或者密码错误.\",\n  \"date\": \"2019-10-19 14:34:34\",\n  \"spent\": 9,\n  \"size\": -1,\n  \"count\": 0,\n  \"position\": 0,\n  \"prompt\": \"com.x.organization.assemble.authentication.jaxrs.authentication.ExceptionPersonNotExistOrInvalidPassword\"\n}",
			    "responseJSON": {
			        "type": "error",
			        "message": "用户不存在或者密码错误.",
			        "date": "2019-10-19 14:34:34",
			        "spent": 9,
			        "size": -1,
			        "count": 0,
			        "position": 0,
			        "prompt": "com.x.organization.assemble.authentication.jaxrs.authentication.ExceptionPersonNotExistOrInvalidPassword"
			    },
			    "status": 500,
			    "statusText": "Internal Server Error"
			}
         * */
        JSONObject result = new JSONObject(responseData);
        String type = result.getString("type");
        if( StringUtils.equals( "success", type )) {
        	//登录成功
        	JSONObject data = result.getJSONObject("data");
            String token = data.getString( "token" );
            return new LoginResult("success", token, "登录成功！");
        }else {
        	//登录失败
        	return new LoginResult("error", null, "用户登录失败！");
        }
    }
    

    /**
     * 发送POST请求
     * 
	 * @param url  地址
	 * @param param   传入的数据
	 * @return
     */
    public static String sendPost( String url, String param ) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            out.print(param);
            out.flush();
            in = new BufferedReader( new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }
    
    public static class LoginResult{
    	private String type;
    	private String token;
    	private String message;
    	
		public LoginResult(String type, String token, String message) {
			super();
			this.type = type;
			this.token = token;
			this.message = message;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getToken() {
			return token;
		}
		public void setToken(String token) {
			this.token = token;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
    }
}
